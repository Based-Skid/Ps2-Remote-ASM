﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
// additional
using System.IO;
using System.Text.RegularExpressions;

namespace Code_to_data_converter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            // switch encryption check box
            cbEncrypt_trigger();            
            encryption_enable();
            // enable dummy line
            cbDummyLine_trigger();
            dummyLine_enable();

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // get patch text from text box
            string patch = tbCodes.Text;
            // checked if encryption is enabled
            Boolean encrypt = false; // set to false by default
            Boolean dummyLine = false; // set to false by default    
            string version = tbVersion.Text;

            // check if dummyline is enabled
            if (cbDummyLine.Checked == true)
            {
                dummyLine = true;
            }

            // check if encryption is enabled
            if (cbEncrypt.Checked == true)
            {
                encrypt = true;
            }
            // remove spaces and other junk
            patch = RemoveSpecialCharacters(patch);
            // write patch to file
            WriteDefaultValues(patch, encrypt, dummyLine, version);
            // clear text box
            tbCodes.Text = "";
        }

        const string fileName = "update.dat";

        public static void WriteDefaultValues(string patch, Boolean encryption, Boolean dummyLine, string version)
        {

            // string length
            int i = patch.Length;
            // counter
            int a = 0;
            // current 4 bytes
            //int bytes;
            uint bytes;

            // encryption key
            uint[] key = { 0xFED04AC6, 0xD427C079, 0x04E76226, 0xD8A47F92,
                           0x059DC5AA, 0xF0347664, 0xD1A4FA22, 0x542AFFCD};

            // variable to keep track of key position
            int k = 0;

            

            // create file
            using (BinaryWriter writer = new BinaryWriter(File.Open(fileName, FileMode.Create)))
            {

                // write dummy line if enabled
                if (dummyLine == true)
                {
                    if (a < (i - 7))
                    {
                        //bytes = 0x000a0000;
                        //writer.Write(bytes);
                        //bytes = 0x00000000;
                        //writer.Write(bytes);

                        //bytes = Encoding.GetBytes(version);
                        writer.Write(Encoding.UTF8.GetBytes(version.PadRight(8, '\0')));
                    }
                }

                // loop through string and write data
                while (a < (i - 7))
                {
                    // get 4 bytes
                    //bytes = Convert.ToInt32(patch.Substring(a, 8), 16);
                    bytes = Convert.ToUInt32(patch.Substring(a, 8), 16);

                    // check if encryption is enabled
                    if (encryption == true){
                        // xor current 4 bytes against key
                        bytes = bytes ^ key[k];
                        // increment key index
                        k++;
                        // check if key position is at end of index
                        if(key.Length <= k)
                        {
                            // reset position
                            k = 0;
                        }
                    }

                    // get first 8 characters of string(4 bytes)
                    writer.Write(bytes);

                    // increment a by 8(4 bytes total)
                    a = a + 8;
                }

                // write 00000000 as last 4 bytes
                bytes = 0x00000000;
                writer.Write(bytes);     

            }            

        }

        public static string RemoveSpecialCharacters(string str)
        {
            return Regex.Replace(str, "[^a-zA-Z0-9_.]+", "", RegexOptions.Compiled);
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            encryption_enable();
        }

        private void encryption_enable()
        {
            if (cbEncrypt.Checked == true)
            {
                Color COLOR_encryption_green = Color.FromArgb(160, 210, 160);
                cbEncrypt.ForeColor = COLOR_encryption_green;
                //pnlEncrypt.BackColor = COLOR_encryption_green;
            }
            else
            {
                Color COLOR_encryption_default = Color.FromArgb(210, 210, 210);
                cbEncrypt.ForeColor = COLOR_encryption_default;
                //pnlEncrypt.BackColor = COLOR_encryption_default;
            }
        }

        private void dummyLine_enable()
        {
            if (cbDummyLine.Checked == true)
            {
                Color COLOR_encryption_green = Color.FromArgb(160, 210, 160);
                cbDummyLine.ForeColor = COLOR_encryption_green;
                //pnlEncrypt.BackColor = COLOR_encryption_green;

                // enable version text box
                tbVersion.Enabled = true;
                Color COLOR_encryption_dark = Color.FromArgb(24, 24, 24);
                tbVersion.BackColor = COLOR_encryption_dark;
            }
            else
            {
                Color COLOR_encryption_default = Color.FromArgb(210, 210, 210);
                cbDummyLine.ForeColor = COLOR_encryption_default;
                //pnlEncrypt.BackColor = COLOR_encryption_default;
                // disable and clear version text box
                tbVersion.Text = "";
                tbVersion.Enabled = false;
                Color COLOR_encryption_dark = Color.FromArgb(52, 52, 52);
                tbVersion.BackColor = COLOR_encryption_dark;
            }
        }

        private void cbEncrypt_trigger()
        {
            // switch encryption check box
            if (cbEncrypt.Checked == true)
            {
                cbEncrypt.Checked = false;
            }
            else { cbEncrypt.Checked = true; }
        }

        private void cbDummyLine_trigger()
        {
            // switch encryption check box
            if (cbDummyLine.Checked == true)
            {
                cbDummyLine.Checked = false;
            }
            else { cbDummyLine.Checked = true; }
        }

        private void pnlEncrypt_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void pnlEncrypt_Click(object sender, EventArgs e)
        {
            // switch encryption check box
            cbEncrypt_trigger();
            // update color
            encryption_enable();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            // switch encryption check box
            cbEncrypt_trigger();
            // update color
            encryption_enable();
        }

        private void cbDummyLine_CheckedChanged(object sender, EventArgs e)
        {
            dummyLine_enable();
        }
    }
}



