﻿namespace Code_to_data_converter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSave = new System.Windows.Forms.Button();
            this.tbCodes = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cbEncrypt = new System.Windows.Forms.CheckBox();
            this.pnlEncrypt = new System.Windows.Forms.Panel();
            this.cbDummyLine = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbVersion = new System.Windows.Forms.TextBox();
            this.pnlEncrypt.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btnSave.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Courier New", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnSave.Location = new System.Drawing.Point(396, 143);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(105, 458);
            this.btnSave.TabIndex = 1;
            this.btnSave.Text = "SAVE";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // tbCodes
            // 
            this.tbCodes.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbCodes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.tbCodes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbCodes.Font = new System.Drawing.Font("Courier New", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbCodes.ForeColor = System.Drawing.Color.DarkKhaki;
            this.tbCodes.Location = new System.Drawing.Point(12, 26);
            this.tbCodes.MaxLength = 999999999;
            this.tbCodes.Multiline = true;
            this.tbCodes.Name = "tbCodes";
            this.tbCodes.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbCodes.Size = new System.Drawing.Size(378, 575);
            this.tbCodes.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Courier New", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label1.Location = new System.Drawing.Point(12, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(136, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Enter Patch Code";
            // 
            // cbEncrypt
            // 
            this.cbEncrypt.AutoSize = true;
            this.cbEncrypt.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbEncrypt.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.cbEncrypt.Location = new System.Drawing.Point(6, 32);
            this.cbEncrypt.Name = "cbEncrypt";
            this.cbEncrypt.Size = new System.Drawing.Size(96, 18);
            this.cbEncrypt.TabIndex = 5;
            this.cbEncrypt.Text = "Encryption";
            this.cbEncrypt.UseVisualStyleBackColor = true;
            this.cbEncrypt.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // pnlEncrypt
            // 
            this.pnlEncrypt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlEncrypt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(62)))), ((int)(((byte)(62)))));
            this.pnlEncrypt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlEncrypt.Controls.Add(this.tbVersion);
            this.pnlEncrypt.Controls.Add(this.cbDummyLine);
            this.pnlEncrypt.Controls.Add(this.label2);
            this.pnlEncrypt.Controls.Add(this.cbEncrypt);
            this.pnlEncrypt.Location = new System.Drawing.Point(396, 26);
            this.pnlEncrypt.Name = "pnlEncrypt";
            this.pnlEncrypt.Size = new System.Drawing.Size(105, 111);
            this.pnlEncrypt.TabIndex = 7;
            // 
            // cbDummyLine
            // 
            this.cbDummyLine.AutoSize = true;
            this.cbDummyLine.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbDummyLine.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.cbDummyLine.Location = new System.Drawing.Point(6, 56);
            this.cbDummyLine.Name = "cbDummyLine";
            this.cbDummyLine.Size = new System.Drawing.Size(89, 18);
            this.cbDummyLine.TabIndex = 9;
            this.cbDummyLine.Text = "Version #";
            this.cbDummyLine.UseVisualStyleBackColor = true;
            this.cbDummyLine.CheckedChanged += new System.EventHandler(this.cbDummyLine_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Courier New", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.Control;
            this.label2.Location = new System.Drawing.Point(18, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 16);
            this.label2.TabIndex = 8;
            this.label2.Text = "Options";
            // 
            // tbVersion
            // 
            this.tbVersion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.tbVersion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbVersion.ForeColor = System.Drawing.Color.DarkKhaki;
            this.tbVersion.Location = new System.Drawing.Point(6, 80);
            this.tbVersion.MaxLength = 7;
            this.tbVersion.Name = "tbVersion";
            this.tbVersion.Size = new System.Drawing.Size(91, 20);
            this.tbVersion.TabIndex = 10;
            this.tbVersion.WordWrap = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            this.ClientSize = new System.Drawing.Size(513, 611);
            this.Controls.Add(this.pnlEncrypt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbCodes);
            this.Controls.Add(this.btnSave);
            this.Name = "Form1";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Code to data converter";
            this.pnlEncrypt.ResumeLayout(false);
            this.pnlEncrypt.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TextBox tbCodes;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox cbEncrypt;
        private System.Windows.Forms.Panel pnlEncrypt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox cbDummyLine;
        private System.Windows.Forms.TextBox tbVersion;
    }
}

